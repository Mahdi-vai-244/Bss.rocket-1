module.exports = {
  content: [
    "./pages/*.{html,js}",
    "./index.html",
    "./js/*.js"
  ],
  theme: {
    extend: {
      colors: {
        primary: "#1a1a1a", // gray-900
        secondary: "#2563eb", // blue-600
        accent: "#25d366", // whatsapp-green
        background: "#ffffff", // white
        surface: "#f8fafc", // slate-50
        text: {
          primary: "#111827", // gray-900
          secondary: "#6b7280", // gray-500
        },
        success: "#10b981", // emerald-500
        warning: "#f59e0b", // amber-500
        error: "#ef4444", // red-500
        border: "#e5e7eb", // gray-200
        whatsapp: "#25d366", // whatsapp-green
        telegram: "#2563eb", // blue-600
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
      },
      fontWeight: {
        normal: '400',
        medium: '500',
        semibold: '600',
        bold: '700',
      },
      boxShadow: {
        subtle: '0 1px 3px rgba(0, 0, 0, 0.1)',
        elevated: '0 4px 6px rgba(0, 0, 0, 0.1)',
      },
      animation: {
        'gentle-glow': 'gentle-glow 2s infinite alternate',
      },
      keyframes: {
        'gentle-glow': {
          '0%': {
            boxShadow: '0 0 5px rgba(37, 99, 235, 0.3)',
          },
          '100%': {
            boxShadow: '0 0 20px rgba(37, 99, 235, 0.6)',
          },
        },
      },
      transitionDuration: {
        smooth: '300ms',
      },
      transitionTimingFunction: {
        smooth: 'ease-in-out',
      },
    },
  },
  plugins: [],
}